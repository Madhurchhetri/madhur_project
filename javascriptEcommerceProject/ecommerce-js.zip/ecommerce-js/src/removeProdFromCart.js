import { getCartProductFromLS } from "./getCartProducts";
import { showToast } from "./showToast";
import { updateCartProductTotal } from "./updateCartProductTotal";
import { updateCartValue } from "./updateCartValue";

export const removeProdFromCart = (id)=>{
    let cartProducts = getCartProductFromLS();
    cartProducts = cartProducts.filter((currElm)=> currElm.id !== id)

    // update the localstorage after removung item

    localStorage.setItem('cartProductLS', JSON.stringify(cartProducts))

    // remove the div to onclick
    let removeDiv = document.getElementById(`card${id}`)
    if(removeDiv){
        removeDiv.remove();

        // show toast when product delete from the cart
        showToast('delete',id);
    }

    updateCartValue(cartProducts)

    updateCartProductTotal()
}