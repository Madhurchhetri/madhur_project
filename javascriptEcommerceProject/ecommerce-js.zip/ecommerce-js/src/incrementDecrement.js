import { getCartProductFromLS } from "./getCartProducts";
import { updateCartProductTotal } from "./updateCartProductTotal";

export const incrementDecrement =(event, id, price, stock)=>{
    const currentCardElement = document.querySelector(`#card${id}`);
    // console.log(currentCardElement);

    const productQuantity = currentCardElement.querySelector('.productQuantity')
    // console.log(productQuantity);

    const productPrice = currentCardElement.querySelector('.productPrice');

    let quantity = 1;
    let localStoragePrice = price;

    // get the data from local storage

      let localCartProducts = getCartProductFromLS();
      let existingProd = localCartProducts.find((curProd)=> curProd.id === id);
      
      if (existingProd){
        quantity = existingProd.quantity;
        localStoragePrice = price = existingProd.price / existingProd.quantity; ;
      }else{
        localStoragePrice =price;
        price =price;
      }

      if (event.target.className === 'cartIncrement'){
        if(quantity < stock){
            quantity += 1;
        }else if(quantity === stock){
            quantity = stock;

        }
    }

    if(event.target.className === 'cartDecrement'){
        if(quantity > 1){
            quantity -= 1;
        }
    }

//  finally we will update the price in localstorage

    localStoragePrice = price * quantity;
    localStoragePrice = Number(localStoragePrice.toFixed(2));

      let updatedCart = {id,quantity,price :localStoragePrice }
       updatedCart = localCartProducts.map((currProd)=>{
            return currProd.id === id ? updatedCart : currProd;
        })
        
        
        localStorage.setItem('cartProductLS', JSON.stringify(updatedCart));

        productQuantity.innerText = quantity;
        productPrice.innerText = localStoragePrice;


        updateCartProductTotal();
}